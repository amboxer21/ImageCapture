# ImageCapturePy
A program to capture a picture and geolocation data upon 3 incorrect attempts at login screen. This data is then e-mailed to you.

**UPDATE**: I resctructured file tree so the build script needs updating!

Run the build script in the Build/Debian dir!

## IMPORTANT!
You must enable less secure apps in your gmail settings or the app will not be able to send notifications!
https://support.google.com/accounts/answer/6010255
